
import java.util.ArrayList;
import java.util.List;

/**
 * ContactService manages a collection of Contact objects in memory.
 *
 * Responsibilities:
 * - Add contacts with a unique contact ID
 * - Delete contacts by contact ID
 * - Update contact fields (firstName, lastName, number, address) by contact ID
 */
public class ContactService {

    // In-memory list of contacts
    private final List<Contact> contactList = new ArrayList<>();

    /**
     * Utility method to find the index of a contact by ID.
     * Returns -1 if not found.
     */
    private int findContactIndex(String contactID) {
        for (int i = 0; i < contactList.size(); i++) {
            if (contactList.get(i).getContactID().equals(contactID)) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Returns the Contact for the given ID.
     * Throws IllegalArgumentException if the ID is not found.
     */
    public Contact getContact(String contactID) {
        int index = findContactIndex(contactID);
        if (index == -1) {
            throw new IllegalArgumentException("Contact ID not found: " + contactID);
        }
        return contactList.get(index);
    }

    /**
     * Adds a new contact with a unique ID.
     * If the contact ID already exists, throws IllegalArgumentException.
     */
    public void addContact(String contactID, String firstName, String lastName,
                           String number, String address) {

        if (findContactIndex(contactID) != -1) {
            throw new IllegalArgumentException("Contact ID must be unique: " + contactID);
        }

        Contact contact = new Contact(contactID, firstName, lastName, number, address);
        contactList.add(contact);
    }

    /**
     * Deletes a contact by contact ID.
     * Throws IllegalArgumentException if the ID is not found.
     */
    public void deleteContact(String contactID) {
        int index = findContactIndex(contactID);
        if (index == -1) {
            throw new IllegalArgumentException("Contact ID not found: " + contactID);
        }
        contactList.remove(index);
    }

    /**
     * Updates firstName for the contact with the given ID.
     */
    public void updateFirstName(String contactID, String newFirstName) {
        Contact contact = getContact(contactID);
        contact.setFirstName(newFirstName);
    }

    /**
     * Updates lastName for the contact with the given ID.
     */
    public void updateLastName(String contactID, String newLastName) {
        Contact contact = getContact(contactID);
        contact.setLastName(newLastName);
    }

    /**
     * Updates phone number for the contact with the given ID.
     */
    public void updateNumber(String contactID, String newNumber) {
        Contact contact = getContact(contactID);
        contact.setNumber(newNumber);
    }

    /**
     * Updates address for the contact with the given ID.
     */
    public void updateAddress(String contactID, String newAddress) {
        Contact contact = getContact(contactID);
        contact.setAddress(newAddress);
    }

    /**
     * Helper method for manual debugging.
     * Prints all contacts to the console.
     */
    public void displayContactList() {
        for (Contact c : contactList) {
            System.out.println("Contact ID: " + c.getContactID());
            System.out.println("  First Name: " + c.getFirstName());
            System.out.println("  Last  Name: " + c.getLastName());
            System.out.println("  Number    : " + c.getNumber());
            System.out.println("  Address   : " + c.getAddress());
            System.out.println();
        }
    }

    // Optional getter if you want to inspect list size in tests
    public int getContactCount() {
        return contactList.size();
    }
}
