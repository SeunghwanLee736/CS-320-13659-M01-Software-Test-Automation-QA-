
/**
 * Contact represents a single contact record in the system.
 * 
 * Requirements:
 * - contactID: required, unique, non-null, max length 10, not updatable
 * - firstName: required, non-null, max length 10
 * - lastName:  required, non-null, max length 10
 * - number:    required, non-null, exactly 10 digits
 * - address:   required, non-null, max length 30
 *
 * If any requirement is violated, the constructor or setter will
 * throw an IllegalArgumentException.
 */
public class Contact {

    private final String contactID;
    private String firstName;
    private String lastName;
    private String number;
    private String address;

    // Constructor
    public Contact(String contactID, String firstName, String lastName,
                   String number, String address) {

        // contactID: required, non-null, <= 10 chars
        if (contactID == null || contactID.length() > 10) {
            throw new IllegalArgumentException(
                "Contact ID must be non-null and at most 10 characters."
            );
        }
        this.contactID = contactID;

        // Use setters so validation logic is in one place
        setFirstName(firstName);
        setLastName(lastName);
        setNumber(number);
        setAddress(address);
    }

    // Getters (no setter for contactID → not updatable)
    public String getContactID() {
        return contactID;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getNumber() {
        return number;
    }

    public String getAddress() {
        return address;
    }

    // Setters with validation

    public void setFirstName(String firstName) {
        if (firstName == null || firstName.length() > 10) {
            throw new IllegalArgumentException(
                "First name must be non-null and at most 10 characters."
            );
        }
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        if (lastName == null || lastName.length() > 10) {
            throw new IllegalArgumentException(
                "Last name must be non-null and at most 10 characters."
            );
        }
        this.lastName = lastName;
    }

    public void setNumber(String number) {
        // Exactly 10 digits, non-null
        if (number == null || !number.matches("\\d{10}")) {
            throw new IllegalArgumentException(
                "Phone number must be exactly 10 digits."
            );
        }
        this.number = number;
    }

    public void setAddress(String address) {
        if (address == null || address.length() > 30) {
            throw new IllegalArgumentException(
                "Address must be non-null and at most 30 characters."
            );
        }
        this.address = address;
    }
}
