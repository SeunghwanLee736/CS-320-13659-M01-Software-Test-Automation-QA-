
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for ContactService.
 * 
 * These tests verify:
 * - Adding contacts with unique IDs
 * - Updating contact fields by ID
 * - Deleting contacts by ID
 */
public class ContactServiceTest {

    @Test
    @DisplayName("Service adds a contact with a unique ID")
    void testAddContact() {
        ContactService service = new ContactService();

        service.addContact("001", "John", "Doe", "1234567890", "123 Main Street");
        Contact contact = service.getContact("001");

        assertEquals("001", contact.getContactID());
        assertEquals("John", contact.getFirstName());
        assertEquals("Doe", contact.getLastName());
        assertEquals("1234567890", contact.getNumber());
        assertEquals("123 Main Street", contact.getAddress());
    }

    @Test
    @DisplayName("Service does not allow duplicate contact IDs")
    void testAddContactDuplicateId() {
        ContactService service = new ContactService();

        service.addContact("001", "John", "Doe", "1234567890", "123 Main Street");

        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact("001", "Jane", "Smith", "0987654321", "456 Second Street");
        });
    }

    @Test
    @DisplayName("Service updates first name by contact ID")
    void testUpdateFirstName() {
        ContactService service = new ContactService();
        service.addContact("001", "John", "Doe", "1234567890", "123 Main Street");

        service.updateFirstName("001", "Sven");

        assertEquals("Sven", service.getContact("001").getFirstName());
    }

    @Test
    @DisplayName("Service updates last name by contact ID")
    void testUpdateLastName() {
        ContactService service = new ContactService();
        service.addContact("001", "John", "Doe", "1234567890", "123 Main Street");

        service.updateLastName("001", "Smith");

        assertEquals("Smith", service.getContact("001").getLastName());
    }

    @Test
    @DisplayName("Service updates phone number by contact ID")
    void testUpdateNumber() {
        ContactService service = new ContactService();
        service.addContact("001", "John", "Doe", "1234567890", "123 Main Street");

        service.updateNumber("001", "0987654321");

        assertEquals("0987654321", service.getContact("001").getNumber());
    }

    @Test
    @DisplayName("Service updates address by contact ID")
    void testUpdateAddress() {
        ContactService service = new ContactService();
        service.addContact("001", "John", "Doe", "1234567890", "123 Main Street");

        service.updateAddress("001", "555 Nowhere Ave");

        assertEquals("555 Nowhere Ave", service.getContact("001").getAddress());
    }

    @Test
    @DisplayName("Service deletes contact by ID")
    void testDeleteContact() {
        ContactService service = new ContactService();
        service.addContact("001", "John", "Doe", "1234567890", "123 Main Street");

        service.deleteContact("001");

        assertEquals(0, service.getContactCount());
        assertThrows(IllegalArgumentException.class, () -> {
            service.getContact("001");
        });
    }

    @Test
    @DisplayName("Service throws when contact ID not found")
    void testGetContactNotFound() {
        ContactService service = new ContactService();
        assertThrows(IllegalArgumentException.class, () -> {
            service.getContact("999");
        });
    }
}
