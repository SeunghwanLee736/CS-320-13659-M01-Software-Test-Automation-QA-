
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for Contact.
 *
 * These tests verify the Contact class requirements:
 * - contactID: non-null, max 10 characters
 * - firstName/lastName: non-null, max 10 characters
 * - number: non-null, exactly 10 digits
 * - address: non-null, max 30 characters
 */
public class ContactTest {

    @Test
    @DisplayName("Valid contact is created successfully")
    void testValidContactCreation() {
        Contact contact = new Contact(
            "12345",
            "John",
            "Doe",
            "1234567890",
            "123 Main Street"
        );

        assertEquals("12345", contact.getContactID());
        assertEquals("John", contact.getFirstName());
        assertEquals("Doe", contact.getLastName());
        assertEquals("1234567890", contact.getNumber());
        assertEquals("123 Main Street", contact.getAddress());
    }

    @Test
    @DisplayName("Contact ID cannot be null")
    void testContactIdNotNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "John", "Doe", "1234567890", "123 Main Street");
        });
    }

    @Test
    @DisplayName("Contact ID cannot be longer than 10 characters")
    void testContactIdMaxLength() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "John", "Doe", "1234567890", "123 Main Street");
        });
    }

    @Test
    @DisplayName("First name cannot be null")
    void testFirstNameNotNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", null, "Doe", "1234567890", "123 Main Street");
        });
    }

    @Test
    @DisplayName("First name cannot be longer than 10 characters")
    void testFirstNameMaxLength() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "VeryLongName", "Doe", "1234567890", "123 Main Street");
        });
    }

    @Test
    @DisplayName("Last name cannot be null")
    void testLastNameNotNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", null, "1234567890", "123 Main Street");
        });
    }

    @Test
    @DisplayName("Last name cannot be longer than 10 characters")
    void testLastNameMaxLength() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "VeryLongLastName", "1234567890", "123 Main Street");
        });
    }

    @Test
    @DisplayName("Phone number must be exactly 10 digits")
    void testPhoneNumberExactTenDigits() {
        // Too short
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "Doe", "123456789", "123 Main Street");
        });

        // Too long
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "Doe", "12345678901", "123 Main Street");
        });

        // Not all digits
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "Doe", "12345abcde", "123 Main Street");
        });
    }

    @Test
    @DisplayName("Address cannot be null")
    void testAddressNotNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "Doe", "1234567890", null);
        });
    }

    @Test
    @DisplayName("Address cannot be longer than 30 characters")
    void testAddressMaxLength() {
        String longAddress = "1234567890123456789012345678901"; // 31 chars
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "Doe", "1234567890", longAddress);
        });
    }

    @Test
    @DisplayName("First name can be updated via setter")
    void testUpdateFirstNameViaSetter() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main Street");
        contact.setFirstName("Jane");
        assertEquals("Jane", contact.getFirstName());
    }

    @Test
    @DisplayName("Phone number can be updated via setter with a valid value")
    void testUpdatePhoneViaSetter() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main Street");
        contact.setNumber("0987654321");
        assertEquals("0987654321", contact.getNumber());
    }
}
