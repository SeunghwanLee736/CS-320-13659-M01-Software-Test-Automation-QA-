
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * AppointmentService manages Appointment objects in memory.
 *
 * Requirements:
 *  - The appointment service shall be able to add appointments with a unique appointment ID.
 *  - The appointment service shall be able to delete appointments per appointment ID.
 *
 * This service does not use a database or user interface; it is verified through JUnit tests.
 */
public class AppointmentService {

    // Internal storage for appointments (in-memory)
    private final List<Appointment> appointmentList = new ArrayList<>();

    /**
     * Adds a new Appointment to the service.
     * The Appointment constructor generates a unique ID.
     * If another Appointment already exists with the same ID (extremely unlikely),
     * an exception is thrown to enforce uniqueness.
     *
     * @param appointmentDate appointment date; must be valid per Appointment rules
     * @param appointmentDesc description; must be valid per Appointment rules
     * @return the newly created Appointment
     */
    public Appointment addAppointment(Date appointmentDate, String appointmentDesc) {
        Appointment appointment = new Appointment(appointmentDate, appointmentDesc);

        // Enforce uniqueness by ID within the service
        for (Appointment existing : appointmentList) {
            if (existing.getAppointmentID().equals(appointment.getAppointmentID())) {
                throw new IllegalArgumentException("Appointment ID must be unique.");
            }
        }

        appointmentList.add(appointment);
        return appointment;
    }

    /**
     * Deletes an appointment by its ID.
     *
     * @param appointmentID the ID of the appointment to delete
     * @throws IllegalArgumentException if the ID does not exist in the list
     */
    public void deleteAppointment(String appointmentID) {
        boolean removed = appointmentList.removeIf(
                appointment -> appointment.getAppointmentID().equals(appointmentID));

        if (!removed) {
            throw new IllegalArgumentException("Appointment ID not found: " + appointmentID);
        }
    }

    /**
     * Helper method for testing – fetch an appointment by ID.
     *
     * @param appointmentID ID of the appointment
     * @return matching Appointment instance or null if not found
     */
    public Appointment getAppointment(String appointmentID) {
        for (Appointment appointment : appointmentList) {
            if (appointment.getAppointmentID().equals(appointmentID)) {
                return appointment;
            }
        }
        return null;
    }

    /**
     * Helper method for testing – returns the number of stored appointments.
     */
    public int getAppointmentCount() {
        return appointmentList.size();
    }
}
