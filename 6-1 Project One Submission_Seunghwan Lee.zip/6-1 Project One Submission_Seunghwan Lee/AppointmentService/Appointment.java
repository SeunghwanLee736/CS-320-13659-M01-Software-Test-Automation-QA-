
import java.util.Date;
import java.util.concurrent.atomic.AtomicLong;

/**
 * The Appointment class represents an immutable appointment object.
 *
 * Project Requirements:
 *  - The appointment object shall have a required unique appointment ID string
 *    that cannot be longer than 10 characters, shall not be null, and
 *    shall not be updatable.
 *
 *  - The appointment object shall have a required appointment Date field.
 *    The appointment Date cannot be in the past and shall not be null.
 *
 *  - The appointment object shall have a required description String field
 *    that cannot be longer than 50 characters and shall not be null.
 *
 * Notes:
 *  - This class generates IDs automatically using a static AtomicLong counter.
 *  - All validations occur in the constructor so the object follows the
 *    "immutable" principle — no setters are provided.
 */
public class Appointment {

    /** Static counter that guarantees unique ID generation across all Appointment instances. */
    private static final AtomicLong idGenerator = new AtomicLong(0);

    /** Appointment ID – final ensures the ID cannot be modified after creation. */
    private final String appointmentID;

    /** Appointment date – immutable after creation (exposed as defensive copy). */
    private final Date appointmentDate;

    /** Appointment description – immutable after creation. */
    private final String appointmentDesc;

    /**
     * Constructor used to create a new Appointment.
     *
     * @param appointmentDate the scheduled appointment date (must not be null, must not be in the past)
     * @param appointmentDesc the appointment description (must not be null and <= 50 characters)
     *
     * @throws IllegalArgumentException if any of the required appointment fields are invalid
     */
    public Appointment(Date appointmentDate, String appointmentDesc) {

        // ----------- Generate and Validate Appointment ID -----------
        String generatedId = String.valueOf(idGenerator.getAndIncrement());

        // ID must not be null and must be 10 characters or fewer
        if (generatedId == null || generatedId.length() > 10) {
            throw new IllegalStateException("Generated appointment ID is invalid.");
        }
        this.appointmentID = generatedId;

        // ----------- Validate Appointment Date -----------
        if (appointmentDate == null) {
            throw new IllegalArgumentException("Appointment date must not be null.");
        }

        // Date cannot be in the past
        if (appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Appointment date cannot be in the past.");
        }

        // Defensive copy to protect internal state
        this.appointmentDate = new Date(appointmentDate.getTime());

        // ----------- Validate Appointment Description -----------
        if (appointmentDesc == null) {
            throw new IllegalArgumentException("Appointment description must not be null.");
        }

        if (appointmentDesc.length() > 50) {
            throw new IllegalArgumentException("Appointment description must be 50 characters or fewer.");
        }

        this.appointmentDesc = appointmentDesc;
    }

    // ===================== GETTERS ===================== //

    /** @return the immutable appointment ID */
    public String getAppointmentID() {
        return appointmentID;
    }

    /**
     * Returns a defensive copy of the appointment date
     * to preserve immutability.
     */
    public Date getAppointmentDate() {
        return new Date(appointmentDate.getTime());
    }

    /** @return the appointment description */
    public String getAppointmentDesc() {
        return appointmentDesc;
    }
}
