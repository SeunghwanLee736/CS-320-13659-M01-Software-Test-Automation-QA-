import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * Unit tests for the Appointment class.
 *
 * These tests verify that:
 *  - Appointment IDs are created and limited to 10 characters.
 *  - Appointment dates must not be null or in the past.
 *  - Descriptions must not be null and must be <= 50 characters.
 */
class AppointmentTest {

    // Utility: get a date 1 day in the future
    private Date getFutureDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, 1);
        return cal.getTime();
    }

    // Utility: get a date 1 day in the past
    private Date getPastDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, -1);
        return cal.getTime();
    }

    @Test
    @DisplayName("Valid appointment is created successfully")
    void testValidAppointmentCreated() {
        Date futureDate = getFutureDate();
        Appointment appointment = new Appointment(futureDate, "Checkup");

        assertNotNull(appointment.getAppointmentID());
        assertTrue(appointment.getAppointmentID().length() <= 10,
                "Appointment ID should be 10 characters or fewer.");
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Checkup", appointment.getAppointmentDesc());
    }

    @Test
    @DisplayName("Appointment date cannot be null")
    void testAppointmentDateNotNull() {
        assertThrows(IllegalArgumentException.class, () ->
                new Appointment(null, "Description"));
    }

    @Test
    @DisplayName("Appointment date cannot be in the past")
    void testAppointmentDateNotInPast() {
        Date pastDate = getPastDate();
        assertThrows(IllegalArgumentException.class, () ->
                new Appointment(pastDate, "Description"));
    }

    @Test
    @DisplayName("Description cannot be null")
    void testAppointmentDescriptionNotNull() {
        Date futureDate = getFutureDate();
        assertThrows(IllegalArgumentException.class, () ->
                new Appointment(futureDate, null));
    }

    @Test
    @DisplayName("Description cannot be longer than 50 characters")
    void testAppointmentDescriptionMaxLength() {
        Date futureDate = getFutureDate();
        String longDescription = "This description is definitely longer than fifty characters in length.";

        assertThrows(IllegalArgumentException.class, () ->
                new Appointment(futureDate, longDescription));
    }
}
