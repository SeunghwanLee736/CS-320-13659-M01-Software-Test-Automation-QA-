import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * Unit tests for the AppointmentService class.
 *
 * These tests verify that:
 *  - Appointments can be added and are stored in memory.
 *  - Generated appointment IDs are unique.
 *  - Appointments can be deleted by their ID.
 *  - Deleting a non-existent ID throws an exception.
 */
class AppointmentServiceTest {

    // Utility: get a date 1 day in the future
    private Date getFutureDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, 1);
        return cal.getTime();
    }

    @Test
    @DisplayName("Service can add a new appointment")
    void testAddAppointment() {
        AppointmentService service = new AppointmentService();
        Date futureDate = getFutureDate();

        Appointment added = service.addAppointment(futureDate, "Dentist Visit");

        assertEquals(1, service.getAppointmentCount());
        assertNotNull(added);
        assertNotNull(service.getAppointment(added.getAppointmentID()));
    }

    @Test
    @DisplayName("Service-generated appointment IDs are unique")
    void testGeneratedAppointmentIdsAreUnique() {
        AppointmentService service = new AppointmentService();
        Date futureDate = getFutureDate();

        Appointment first = service.addAppointment(futureDate, "First");
        Appointment second = service.addAppointment(futureDate, "Second");

        assertNotEquals(first.getAppointmentID(), second.getAppointmentID(),
                "Each appointment should have a unique ID.");
    }

    @Test
    @DisplayName("Service can delete an appointment by ID")
    void testDeleteAppointment() {
        AppointmentService service = new AppointmentService();
        Date futureDate = getFutureDate();

        Appointment added = service.addAppointment(futureDate, "Meeting");
        assertEquals(1, service.getAppointmentCount());

        service.deleteAppointment(added.getAppointmentID());
        assertEquals(0, service.getAppointmentCount());
        assertNull(service.getAppointment(added.getAppointmentID()));
    }

    @Test
    @DisplayName("Deleting a non-existent appointment ID throws exception")
    void testDeleteNonExistingAppointmentThrows() {
        AppointmentService service = new AppointmentService();

        assertThrows(IllegalArgumentException.class, () ->
                service.deleteAppointment("does-not-exist"));
    }

    @Test
    @DisplayName("getAppointment returns null when ID not found")
    void testGetAppointmentNotFound() {
        AppointmentService service = new AppointmentService();
        assertNull(service.getAppointment("no-such-id"),
                "Non-existing ID should return null.");
    }
}
