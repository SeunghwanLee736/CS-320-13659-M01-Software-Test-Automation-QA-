import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * Unit tests for the Task class.
 *
 * These tests verify that:
 *  - Fields respect maximum length constraints:
 *      * task ID <= 10 characters
 *      * task name <= 20 characters
 *      * task description <= 50 characters
 *  - Fields are required (not null)
 *  - Task ID is not updatable after construction
 */
class TaskTest {

    @Test
    @DisplayName("Valid task is created successfully")
    void testValidTaskCreation() {
        Task task = new Task("ID123", "Name", "Description");
        assertEquals("ID123", task.getTaskID());
        assertEquals("Name", task.getTaskName());
        assertEquals("Description", task.getTaskDesc());
    }

    @Test
    @DisplayName("Task ID longer than 10 characters should throw exception")
    void testTaskIDTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Name", "Description");
        });
    }

    @Test
    @DisplayName("Task name longer than 20 characters should throw exception")
    void testTaskNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("ID123", "ThisNameIsWayTooLongToBeValid", "Description");
        });
    }

    @Test
    @DisplayName("Task description longer than 50 characters should throw exception")
    void testTaskDescTooLong() {
        String longDesc = "This description is definitely going to be longer than fifty characters.";
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("ID123", "Name", longDesc);
        });
    }

    @Test
    @DisplayName("Task ID shall not be null")
    void testTaskIDNotNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Name", "Description");
        });
    }

    @Test
    @DisplayName("Task name shall not be null")
    void testTaskNameNotNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("ID123", null, "Description");
        });
    }

    @Test
    @DisplayName("Task description shall not be null")
    void testTaskDescNotNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("ID123", "Name", null);
        });
    }

    @Test
    @DisplayName("Task ID is not updatable after construction")
    void testTaskIDNotUpdatable() {
        Task task = new Task("ID123", "Name", "Description");
        String originalID = task.getTaskID();
        task.setTaskName("New Name");
        task.setTaskDesc("New Description");
        assertEquals(originalID, task.getTaskID(), "Task ID should not change after updates.");
    }
}
