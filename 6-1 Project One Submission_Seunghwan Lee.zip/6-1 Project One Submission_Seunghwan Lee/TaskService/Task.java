/**
 * The Task class represents a single task in the system.
 *
 * Requirements:
 *  - Each task has a required, unique task ID (String) that:
 *      * is not null
 *      * is not longer than 10 characters
 *      * cannot be updated after construction
 *  - Each task has a required name (String) that:
 *      * is not null
 *      * is not longer than 20 characters
 *  - Each task has a required description (String) that:
 *      * is not null
 *      * is not longer than 50 characters
 *
 * Any violation of these constraints results in an IllegalArgumentException.
 */
public class Task {

    // Fields
    private final String taskID;
    private String taskName;
    private String taskDesc;

    /**
     * Constructs a Task with the given ID, name, and description.
     *
     * @param taskID    Unique identifier for the task, max 10 characters, not null
     * @param taskName  Name of the task, max 20 characters, not null
     * @param taskDesc  Description of the task, max 50 characters, not null
     * @throws IllegalArgumentException if any parameter is null or exceeds its max length
     */
    public Task(String taskID, String taskName, String taskDesc) {
        if (taskID == null || taskID.length() > 10) {
            throw new IllegalArgumentException("Task ID must be non-null and at most 10 characters.");
        }
        if (taskName == null || taskName.length() > 20) {
            throw new IllegalArgumentException("Task name must be non-null and at most 20 characters.");
        }
        if (taskDesc == null || taskDesc.length() > 50) {
            throw new IllegalArgumentException("Task description must be non-null and at most 50 characters.");
        }

        this.taskID = taskID;
        this.taskName = taskName;
        this.taskDesc = taskDesc;
    }

    // Getters

    /**
     * Returns the task ID. This value is immutable.
     *
     * @return the task ID
     */
    public String getTaskID() {
        return taskID;
    }

    /**
     * Returns the task name.
     *
     * @return the task name
     */
    public String getTaskName() {
        return taskName;
    }

    /**
     * Returns the task description.
     *
     * @return the task description
     */
    public String getTaskDesc() {
        return taskDesc;
    }

    // Setters (only for name and description)

    /**
     * Updates the task name.
     * Name must be non-null and not longer than 20 characters.
     *
     * @param taskName new task name
     * @throws IllegalArgumentException if taskName is null or longer than 20 characters
     */
    public void setTaskName(String taskName) {
        if (taskName == null || taskName.length() > 20) {
            throw new IllegalArgumentException("Task name must be non-null and at most 20 characters.");
        }
        this.taskName = taskName;
    }

    /**
     * Updates the task description.
     * Description must be non-null and not longer than 50 characters.
     *
     * @param taskDesc new task description
     * @throws IllegalArgumentException if taskDesc is null or longer than 50 characters
     */
    public void setTaskDesc(String taskDesc) {
        if (taskDesc == null || taskDesc.length() > 50) {
            throw new IllegalArgumentException("Task description must be non-null and at most 50 characters.");
        }
        this.taskDesc = taskDesc;
    }
}
