import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * Unit tests for the TaskService class.
 *
 * These tests verify that the service:
 *  - Can add tasks with a unique ID
 *  - Rejects duplicate IDs
 *  - Can delete tasks by ID
 *  - Can update task name and description by ID
 */
class TaskServiceTest {

    @Test
    @DisplayName("Service can add a task with a unique ID")
    void testAddTask() {
        TaskService service = new TaskService();
        service.addTask("1", "Task Name", "Task Description");

        Task retrieved = service.getTask("1");
        assertNotNull(retrieved, "Task should be added and retrievable by ID.");
        assertEquals("Task Name", retrieved.getTaskName());
        assertEquals("Task Description", retrieved.getTaskDesc());
    }

    @Test
    @DisplayName("Service should not allow duplicate task IDs")
    void testAddTaskWithDuplicateID() {
        TaskService service = new TaskService();
        service.addTask("1", "Task One", "Description One");

        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask("1", "Task Two", "Description Two");
        }, "Adding a task with a duplicate ID should throw an exception.");
    }

    @Test
    @DisplayName("Service can delete a task by ID")
    void testDeleteTask() {
        TaskService service = new TaskService();
        service.addTask("1", "Task Name", "Task Description");

        service.deleteTask("1");
        Task retrieved = service.getTask("1");

        assertNull(retrieved, "Task should be deleted and no longer retrievable.");
        List<Task> tasks = service.getTaskList();
        assertTrue(tasks.isEmpty(), "Task list should be empty after deletion.");
    }

    @Test
    @DisplayName("Service can update task name by ID")
    void testUpdateTaskName() {
        TaskService service = new TaskService();
        service.addTask("1", "Old Name", "Description");

        service.updateTaskName("1", "New Name");
        Task retrieved = service.getTask("1");

        assertNotNull(retrieved, "Task should exist for update.");
        assertEquals("New Name", retrieved.getTaskName(), "Task name should be updated.");
    }

    @Test
    @DisplayName("Service can update task description by ID")
    void testUpdateTaskDesc() {
        TaskService service = new TaskService();
        service.addTask("1", "Name", "Old Description");

        service.updateTaskDesc("1", "New Description");
        Task retrieved = service.getTask("1");

        assertNotNull(retrieved, "Task should exist for update.");
        assertEquals("New Description", retrieved.getTaskDesc(), "Task description should be updated.");
    }

    @Test
    @DisplayName("Service returns null when task ID is not found")
    void testGetTaskNotFound() {
        TaskService service = new TaskService();
        Task retrieved = service.getTask("999");
        assertNull(retrieved, "Non-existing task ID should return null.");
    }

    @Test
    @DisplayName("Updating non-existing task does nothing (no exception)")
    void testUpdateNonExistingTaskDoesNothing() {
        TaskService service = new TaskService();
        // No tasks added

        // These should not throw
        service.updateTaskName("999", "Name");
        service.updateTaskDesc("999", "Desc");

        // List should still be empty
        assertTrue(service.getTaskList().isEmpty(), "Task list should remain empty.");
    }
}
