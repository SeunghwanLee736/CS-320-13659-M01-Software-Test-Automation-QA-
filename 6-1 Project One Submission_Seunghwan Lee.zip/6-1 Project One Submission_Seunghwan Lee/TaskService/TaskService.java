import java.util.ArrayList;
import java.util.List;

/**
 * TaskService manages a collection of Task objects in memory.
 *
 * Requirements:
 *  - The service can add tasks with a unique ID.
 *  - The service can delete tasks by task ID.
 *  - The service can update task name and description by task ID.
 *
 * This class does not use a database or user interface.
 * All data is stored in an in-memory list, and behavior is verified through JUnit tests.
 */
public class TaskService {

    // In-memory list of tasks managed by the service
    private final List<Task> taskList = new ArrayList<>();

    /**
     * Returns the internal list of tasks.
     * This is primarily useful for testing and debugging.
     *
     * @return List of tasks
     */
    public List<Task> getTaskList() {
        return taskList;
    }

    /**
     * Adds a new task to the service.
     * The task ID must be unique within the service.
     *
     * @param taskID   unique ID for the new task
     * @param name     name of the task
     * @param desc     description of the task
     * @throws IllegalArgumentException if a task with the same ID already exists
     */
    public void addTask(String taskID, String name, String desc) {
        if (getTask(taskID) != null) {
            throw new IllegalArgumentException("Task ID must be unique. Duplicate ID: " + taskID);
        }
        Task task = new Task(taskID, name, desc);
        taskList.add(task);
    }

    /**
     * Retrieves a task by its ID.
     *
     * @param taskID the ID of the task to retrieve
     * @return the Task with the matching ID, or null if not found
     */
    public Task getTask(String taskID) {
        for (Task task : taskList) {
            if (task.getTaskID().equals(taskID)) {
                return task;
            }
        }
        return null;
    }

    /**
     * Deletes a task by its ID.
     * If the task is not found, the method completes silently.
     *
     * @param taskID the ID of the task to delete
     */
    public void deleteTask(String taskID) {
        Task task = getTask(taskID);
        if (task != null) {
            taskList.remove(task);
        }
    }

    /**
     * Updates the name of a task identified by its ID.
     * If the task is not found, no update occurs.
     *
     * @param taskID      ID of the task to update
     * @param updatedName new name to apply
     * @throws IllegalArgumentException if the new name is invalid
     */
    public void updateTaskName(String taskID, String updatedName) {
        Task task = getTask(taskID);
        if (task != null) {
            task.setTaskName(updatedName);
        }
    }

    /**
     * Updates the description of a task identified by its ID.
     * If the task is not found, no update occurs.
     *
     * @param taskID        ID of the task to update
     * @param updatedDesc   new description to apply
     * @throws IllegalArgumentException if the new description is invalid
     */
    public void updateTaskDesc(String taskID, String updatedDesc) {
        Task task = getTask(taskID);
        if (task != null) {
            task.setTaskDesc(updatedDesc);
        }
    }

    /**
     * Utility method to print all tasks to the console.
     * This can be helpful during manual debugging.
     */
    public void displayTaskList() {
        for (Task task : taskList) {
            System.out.println("Task ID: " + task.getTaskID());
            System.out.println("\tName: " + task.getTaskName());
            System.out.println("\tDescription: " + task.getTaskDesc());
        }
    }
}
